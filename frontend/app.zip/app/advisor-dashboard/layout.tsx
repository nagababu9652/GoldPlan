"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  BarChart3,
  Bell,
  BriefcaseBusiness,
  FileText,
  FolderKanban,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquare,
  Search,
  UserRound,
  Users,
  X,
} from "lucide-react";

const sidebarItems = [
  {
    label: "Dashboard",
    icon: LayoutDashboard,
    path: "/advisor-dashboard",
  },
  {
    label: "Clients",
    icon: Users,
    path: "/advisor-dashboard/clients",
  },
  {
    label: "Groups",
    icon: FolderKanban,
    path: "/advisor-dashboard/groups",
  },
  {
    label: "Portfolio",
    icon: BarChart3,
    path: "/advisor-dashboard/portfolio",
  },
  {
    label: "Reports",
    icon: FileText,
    path: "/advisor-dashboard/reports",
  },
  {
    label: "Documents",
    icon: BriefcaseBusiness,
    path: "/advisor-dashboard/documents",
  },
  {
    label: "Messages",
    icon: MessageSquare,
    path: "/advisor-dashboard/messages",
  },
  {
    label: "Profile",
    icon: UserRound,
    path: "/advisor-dashboard/profile",
  },
];

export default function AdvisorDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userName, setUserName] = useState("Advisor");

  useEffect(() => {
    const token = localStorage.getItem("finplan_token");
    const userStr = localStorage.getItem("finplan_user");

    if (!token) {
      router.replace("/login");
      return;
    }

    if (userStr) {
      try {
        const user = JSON.parse(userStr);

        if (user.role && user.role !== "advisor") {
          router.replace("/dashboard");
          return;
        }

        setUserName(
          user.name ||
            user.full_name ||
            user.email?.split("@")[0] ||
            "Advisor"
        );
      } catch {
        setUserName("Advisor");
      }
    }
  }, [router]);

  useEffect(() => {
    setSidebarOpen(false);
  }, [pathname]);

  const handleLogout = () => {
    localStorage.removeItem("finplan_token");
    localStorage.removeItem("finplan_refresh_token");
    localStorage.removeItem("finplan_user");

    router.replace("/login");
  };

  return (
    <div className="min-h-screen bg-bone text-obsidian">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <button
          type="button"
          aria-label="Close sidebar"
          className="fixed inset-0 z-40 bg-obsidian/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside
          className={[
            "fixed inset-y-0 left-0 z-50 flex w-[260px] flex-col",
            "bg-obsidian text-bone",
            "transition-transform duration-200 ease-out",
            "lg:static lg:z-auto lg:translate-x-0",
            sidebarOpen ? "translate-x-0" : "-translate-x-full",
          ].join(" ")}
        >
          {/* Brand */}
          <div className="flex items-center justify-between border-b border-obsidian-soft px-6 py-7">
            <Link href="/" className="group">
              <div className="font-serif text-[26px] leading-none text-antique-light">
                FinPlan.
              </div>

              <div className="mt-2 font-mono text-[10px] uppercase tracking-[0.18em] text-ash-light">
                Advisor Portal
              </div>
            </Link>

            <button
              type="button"
              aria-label="Close sidebar"
              className="rounded-md p-2 text-ash-light transition-colors hover:bg-obsidian-soft hover:text-bone lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X size={19} />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto px-3 py-6">
            <div className="mb-3 px-3 font-mono text-[10px] uppercase tracking-[0.16em] text-ash-light">
              Workspace
            </div>

            <div className="space-y-1">
              {sidebarItems.map((item) => {
                const Icon = item.icon;

                const isActive =
                  pathname === item.path ||
                  (item.path !== "/advisor-dashboard" &&
                    pathname.startsWith(`${item.path}/`));

                return (
                  <Link
                    key={item.path}
                    href={item.path}
                    className={[
                      "flex items-center gap-3 rounded-lg px-3 py-2.5",
                      "text-[14px] transition-colors",
                      isActive
                        ? "bg-antique text-obsidian"
                        : "text-ash-light hover:bg-obsidian-soft hover:text-bone",
                    ].join(" ")}
                  >
                    <Icon size={18} strokeWidth={1.8} />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </nav>

          {/* User / Logout */}
          <div className="border-t border-obsidian-soft p-4">
            <div className="mb-3 flex items-center gap-3 rounded-lg bg-obsidian-soft px-3 py-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-antique font-medium text-obsidian">
                {userName.charAt(0).toUpperCase()}
              </div>

              <div className="min-w-0">
                <div className="truncate text-sm text-bone">
                  {userName}
                </div>

                <div className="font-mono text-[10px] uppercase tracking-wider text-ash-light">
                  Advisor
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleLogout}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-ash-light transition-colors hover:bg-obsidian-soft hover:text-bone"
            >
              <LogOut size={17} strokeWidth={1.8} />
              <span>Logout</span>
            </button>
          </div>
        </aside>

        {/* Main area */}
        <div className="flex min-h-screen min-w-0 flex-1 flex-col">
          {/* Top bar */}
          <header className="sticky top-0 z-30 border-b border-line bg-bone/95 backdrop-blur">
            <div className="flex min-h-[68px] items-center gap-4 px-4 sm:px-6 lg:px-8">
              {/* Mobile menu */}
              <button
                type="button"
                aria-label="Open sidebar"
                className="rounded-lg p-2 text-ash transition-colors hover:bg-bone-deep hover:text-obsidian lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu size={21} />
              </button>

              {/* Search */}
              <div className="hidden max-w-xl flex-1 md:block">
                <div className="flex items-center gap-3">
                  <Search size={18} className="text-ash" />

                  <input
                    type="search"
                    placeholder="Search clients, reports, documents..."
                    className="w-full bg-transparent text-sm text-obsidian outline-none placeholder:text-ash"
                  />
                </div>
              </div>

              <div className="ml-auto flex items-center gap-3">
                {/* Notifications */}
                <Link
                  href="/advisor-dashboard/notifications"
                  aria-label="Notifications"
                  className="relative rounded-lg p-2.5 text-ash transition-colors hover:bg-bone-deep hover:text-obsidian"
                >
                  <Bell size={19} strokeWidth={1.8} />

                  <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-obsidian px-1 font-mono text-[9px] text-bone">
                    2
                  </span>
                </Link>

                {/* Profile */}
                <Link
                  href="/advisor-dashboard/profile"
                  className="flex items-center gap-3 rounded-lg px-2 py-1.5 transition-colors hover:bg-bone-deep"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-antique font-medium text-obsidian">
                    {userName.charAt(0).toUpperCase()}
                  </div>

                  <div className="hidden text-left sm:block">
                    <div className="max-w-[130px] truncate text-sm font-medium">
                      {userName}
                    </div>

                    <div className="font-mono text-[10px] uppercase tracking-wider text-ash">
                      Advisor
                    </div>
                  </div>
                </Link>
              </div>
            </div>
          </header>

          {/* Page */}
          <main className="min-w-0 flex-1">{children}</main>
        </div>
      </div>
    </div>
  );
}