"use client";

import { useEffect, useState } from "react";
import {
  getAdvisorPortfolio,
  type AdvisorPortfolio,
} from "@/lib/api";

interface PortfolioPerformanceProps {
  height?: number;
}

function formatCurrency(value: number) {
  if (value >= 10000000) {
    return `₹${(value / 10000000).toFixed(2)} Cr`;
  }

  if (value >= 100000) {
    return `₹${(value / 100000).toFixed(2)} L`;
  }

  return `₹${value.toLocaleString("en-IN")}`;
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
}

export default function PortfolioPerformance({
  height = 320,
}: PortfolioPerformanceProps) {
  const [portfolio, setPortfolio] = useState<AdvisorPortfolio | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadPortfolio() {
      try {
        setLoading(true);
        setError("");

        const token = localStorage.getItem("finplan_token");

        if (!token) {
          throw new Error("Authentication required");
        }

        const data = await getAdvisorPortfolio(token);
        setPortfolio(data);
      } catch (err) {
        setError(
          err instanceof Error
            ? err.message
            : "Failed to load portfolio"
        );
      } finally {
        setLoading(false);
      }
    }

    loadPortfolio();
  }, []);

  if (loading) {
    return (
      <section className="rounded-2xl border border-line bg-bone p-6">
        <div className="mb-6">
          <div className="label-mono text-ash">
            Portfolio Performance
          </div>

          <h2 className="mt-2 font-serif text-2xl text-obsidian">
            Assets under management
          </h2>

          <p className="mt-1 text-sm text-ash">
            Current portfolio performance and allocation
          </p>
        </div>

        <div
          className="animate-pulse rounded-xl bg-ash/10"
          style={{ height }}
        />
      </section>
    );
  }

  if (error || !portfolio) {
    return (
      <section className="rounded-2xl border border-line bg-bone p-6">
        <div className="mb-6">
          <div className="label-mono text-ash">
            Portfolio Performance
          </div>

          <h2 className="mt-2 font-serif text-2xl text-obsidian">
            Assets under management
          </h2>
        </div>

        <div className="flex items-center justify-center rounded-xl border border-red-200 bg-red-50 p-8 text-sm text-red-600">
          {error || "Unable to load portfolio"}
        </div>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border border-line bg-bone p-6">
      {/* Header */}
      <div className="mb-6">
        <div className="label-mono text-ash">
          Portfolio Performance
        </div>

        <div className="mt-2 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <h2 className="font-serif text-2xl text-obsidian">
              Assets under management
            </h2>

            <p className="mt-1 text-sm text-ash">
              Current portfolio value and asset allocation
            </p>
          </div>

          <div className="text-left sm:text-right">
            <p className="text-3xl font-semibold tracking-tight text-obsidian">
              {formatCurrency(portfolio.total_value)}
            </p>

            <p
              className={`mt-1 text-sm font-medium ${
                portfolio.returns_percentage >= 0
                  ? "text-green-600"
                  : "text-red-600"
              }`}
            >
              {formatPercent(portfolio.returns_percentage)} returns
            </p>
          </div>
        </div>
      </div>

      {/* Portfolio summary */}
      <div className="mb-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-line bg-white/60 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-ash">
            Invested
          </p>

          <p className="mt-2 text-lg font-semibold text-obsidian">
            {formatCurrency(portfolio.total_cost)}
          </p>
        </div>

        <div className="rounded-xl border border-line bg-white/60 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-ash">
            Total Returns
          </p>

          <p
            className={`mt-2 text-lg font-semibold ${
              portfolio.total_returns >= 0
                ? "text-green-600"
                : "text-red-600"
            }`}
          >
            {formatCurrency(portfolio.total_returns)}
          </p>
        </div>

        <div className="rounded-xl border border-line bg-white/60 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-ash">
            Return %
          </p>

          <p
            className={`mt-2 text-lg font-semibold ${
              portfolio.returns_percentage >= 0
                ? "text-green-600"
                : "text-red-600"
            }`}
          >
            {formatPercent(portfolio.returns_percentage)}
          </p>
        </div>
      </div>

      {/* Asset allocation */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-obsidian">
            Asset Allocation
          </h3>

          <span className="text-xs text-ash">
            {portfolio.holdings.length} holdings
          </span>
        </div>

        <div className="space-y-5">
          {portfolio.holdings.map((holding) => (
            <div key={holding.name}>
              <div className="mb-2 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-obsidian">
                    {holding.name}
                  </p>

                  <p className="mt-0.5 text-xs text-ash">
                    {formatCurrency(holding.value)}
                  </p>
                </div>

                <div className="shrink-0 text-right">
                  <p className="text-sm font-semibold text-obsidian">
                    {holding.allocation}%
                  </p>

                  <p
                    className={`text-xs ${
                      holding.returns >= 0
                        ? "text-green-600"
                        : "text-red-600"
                    }`}
                  >
                    {formatPercent(holding.returns)}
                  </p>
                </div>
              </div>

              <div className="h-2 overflow-hidden rounded-full bg-ash/10">
                <div
                  className="h-full rounded-full bg-obsidian transition-all duration-500"
                  style={{
                    width: `${Math.min(
                      Math.max(holding.allocation, 0),
                      100
                    )}%`,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}