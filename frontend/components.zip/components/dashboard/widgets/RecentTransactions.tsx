"use client";

import Link from "next/link";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowRight,
} from "lucide-react";

type TransactionType = "investment" | "withdrawal" | "sip";

interface Transaction {
  id: string;
  client: string;
  type: TransactionType;
  amount: number;
  date: string;
  status: "Completed" | "Pending";
}

const transactions: Transaction[] = [
  {
    id: "TXN-1024",
    client: "Rahul Sharma",
    type: "investment",
    amount: 150000,
    date: "Today, 09:42 AM",
    status: "Completed",
  },
  {
    id: "TXN-1023",
    client: "Priya Patel",
    type: "sip",
    amount: 25000,
    date: "Today, 08:15 AM",
    status: "Completed",
  },
  {
    id: "TXN-1022",
    client: "Arjun Reddy",
    type: "withdrawal",
    amount: 75000,
    date: "Yesterday",
    status: "Pending",
  },
  {
    id: "TXN-1021",
    client: "Sneha Rao",
    type: "investment",
    amount: 200000,
    date: "Yesterday",
    status: "Completed",
  },
];

function formatCurrency(amount: number) {
  return `₹${amount.toLocaleString("en-IN")}`;
}

function TransactionIcon({
  type,
}: {
  type: TransactionType;
}) {
  if (type === "withdrawal") {
    return (
      <div className="flex h-9 w-9 items-center justify-center rounded-full border border-line">
        <ArrowDownLeft size={16} className="text-red-600" />
      </div>
    );
  }

  return (
    <div className="flex h-9 w-9 items-center justify-center rounded-full border border-line">
      <ArrowUpRight size={16} className="text-emerald-700" />
    </div>
  );
}

export default function RecentTransactions() {
  return (
    <section className="overflow-hidden rounded-2xl border border-line bg-bone">
      <div className="flex items-center justify-between border-b border-line p-6">
        <div>
          <div className="label-mono text-ash">
            Financial Activity
          </div>

          <h2 className="mt-2 font-serif text-2xl text-obsidian">
            Recent Transactions
          </h2>
        </div>

        <Link
          href="/advisor-dashboard/portfolio"
          className="hidden items-center gap-2 text-xs font-mono uppercase tracking-wider2 text-obsidian u-link sm:inline-flex"
        >
          View portfolio
          <ArrowRight size={14} />
        </Link>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[680px]">
          <thead>
            <tr className="border-b border-line text-left">
              <th className="px-6 py-4 text-[11px] font-mono uppercase tracking-wider text-ash">
                Client
              </th>

              <th className="px-6 py-4 text-[11px] font-mono uppercase tracking-wider text-ash">
                Type
              </th>

              <th className="px-6 py-4 text-[11px] font-mono uppercase tracking-wider text-ash">
                Amount
              </th>

              <th className="px-6 py-4 text-[11px] font-mono uppercase tracking-wider text-ash">
                Date
              </th>

              <th className="px-6 py-4 text-[11px] font-mono uppercase tracking-wider text-ash">
                Status
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-line">
            {transactions.map((transaction) => (
              <tr
                key={transaction.id}
                className="transition-colors hover:bg-bone-deep"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <TransactionIcon type={transaction.type} />

                    <div>
                      <div className="text-sm font-medium text-obsidian">
                        {transaction.client}
                      </div>

                      <div className="mt-0.5 text-[11px] font-mono text-ash">
                        {transaction.id}
                      </div>
                    </div>
                  </div>
                </td>

                <td className="px-6 py-4 text-sm text-ash">
                  {transaction.type === "sip"
                    ? "SIP"
                    : transaction.type === "investment"
                    ? "Investment"
                    : "Withdrawal"}
                </td>

                <td className="px-6 py-4 font-serif text-sm text-obsidian">
                  {formatCurrency(transaction.amount)}
                </td>

                <td className="px-6 py-4 text-xs text-ash">
                  {transaction.date}
                </td>

                <td className="px-6 py-4">
                  <span
                    className={`inline-flex rounded-full border px-3 py-1 text-[10px] font-mono uppercase tracking-wide ${
                      transaction.status === "Completed"
                        ? "border-emerald-700/30 text-emerald-700"
                        : "border-amber-700/30 text-amber-700"
                    }`}
                  >
                    {transaction.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Link
        href="/advisor-dashboard/portfolio"
        className="flex items-center justify-center gap-2 border-t border-line p-4 text-xs font-mono uppercase tracking-wider text-ash transition-colors hover:bg-bone-deep hover:text-obsidian sm:hidden"
      >
        View portfolio
        <ArrowRight size={14} />
      </Link>
    </section>
  );
}