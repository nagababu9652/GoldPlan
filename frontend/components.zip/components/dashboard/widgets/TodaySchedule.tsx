"use client";

import { useEffect, useState } from "react";
import {
  getAdvisorTodayMeetings,
  type AdvisorMeeting,
} from "@/lib/api";

function formatTime(time: string) {
  const [hours, minutes] = time.split(":");

  const date = new Date();
  date.setHours(Number(hours), Number(minutes), 0, 0);

  return date.toLocaleTimeString("en-IN", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

function meetingTypeLabel(
  type: AdvisorMeeting["meeting_type"]
) {
  switch (type) {
    case "in_person":
      return "In Person";
    case "phone":
      return "Phone";
    default:
      return "Virtual";
  }
}

export default function TodaySchedule() {
  const [meetings, setMeetings] = useState<AdvisorMeeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadMeetings() {
      try {
        setLoading(true);
        setError("");

        const token = localStorage.getItem("finplan_token");

        if (!token) {
          throw new Error("Authentication required");
        }

        const response = await getAdvisorTodayMeetings(token);

        setMeetings(response.meetings);
      } catch (err) {
        setError(
          err instanceof Error
            ? err.message
            : "Failed to load today's meetings"
        );
      } finally {
        setLoading(false);
      }
    }

    loadMeetings();
  }, []);

  return (
    <section className="rounded-2xl border border-line bg-bone">
      {/* Header */}
      <div className="border-b border-line p-6">
        <div className="label-mono text-ash">
          Today's Schedule
        </div>

        <div className="mt-2 flex items-end justify-between gap-4">
          <h3 className="font-serif text-2xl text-obsidian">
            {loading
              ? "Loading..."
              : `${meetings.length} ${
                  meetings.length === 1
                    ? "Scheduled Activity"
                    : "Scheduled Activities"
                }`}
          </h3>

          <span className="text-sm text-ash">
            Today
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((item) => (
              <div
                key={item}
                className="animate-pulse rounded-xl border border-line p-5"
              >
                <div className="h-4 w-2/3 rounded bg-ash/10" />
                <div className="mt-3 h-3 w-1/3 rounded bg-ash/10" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="rounded-xl border border-red-200 bg-red-50 p-5 text-sm text-red-600">
            {error}
          </div>
        ) : meetings.length === 0 ? (
          <div className="flex min-h-[220px] items-center justify-center">
            <div className="max-w-xs text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full border border-line">
                <span className="text-lg text-ash">
                  ◷
                </span>
              </div>

              <h4 className="font-medium text-obsidian">
                No meetings today
              </h4>

              <p className="mt-2 text-sm leading-6 text-ash">
                You currently have no scheduled meetings
                for today.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {meetings.map((meeting) => (
              <div
                key={meeting.id}
                className="rounded-xl border border-line bg-white/60 p-5 transition-colors hover:bg-white"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <p className="font-medium text-obsidian">
                      {meeting.title}
                    </p>

                    <p className="mt-1 text-sm text-ash">
                      {meeting.client_name}
                    </p>
                  </div>

                  <span className="shrink-0 text-sm font-semibold text-obsidian">
                    {formatTime(meeting.meeting_time)}
                  </span>
                </div>

                <div className="mt-4 flex items-center justify-between gap-3">
                  <span className="rounded-full border border-line px-3 py-1 text-xs text-ash">
                    {meetingTypeLabel(meeting.meeting_type)}
                  </span>

                  <span className="text-xs font-medium capitalize text-green-600">
                    {meeting.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        <a
          href="/advisor-dashboard/meetings"
          className="mt-5 inline-flex text-sm font-medium text-obsidian underline underline-offset-4 transition-opacity hover:opacity-70"
        >
          View all meetings →
        </a>
      </div>
    </section>
  );
}