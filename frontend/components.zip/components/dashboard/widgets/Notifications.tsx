"use client";

import Link from "next/link";
import {
  ArrowUpRight,
  Bell,
} from "lucide-react";

export default function Notifications() {
  return (
    <section className="overflow-hidden rounded-2xl border border-line bg-bone">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-line p-6">
        <div>
          <div className="label-mono text-ash">
            Activity
          </div>

          <h2 className="mt-2 font-serif text-2xl text-obsidian">
            Notifications
          </h2>
        </div>

        <Link
          href="/advisor-dashboard/notifications"
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider2 text-obsidian u-link"
        >
          View all
          <ArrowUpRight size={14} />
        </Link>
      </div>

      {/* Empty state */}
      <div className="flex min-h-[260px] flex-col items-center justify-center px-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full border border-line">
          <Bell size={20} className="text-ash" />
        </div>

        <h3 className="mt-4 text-sm font-medium text-obsidian">
          No new notifications
        </h3>

        <p className="mt-2 max-w-xs text-xs leading-5 text-ash">
          Notifications will appear here when there is new activity
          requiring your attention.
        </p>
      </div>
    </section>
  );
}