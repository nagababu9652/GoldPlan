"use client";

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  trend?: number;
  icon?: React.ReactNode;
}

export default function StatCard({
  title,
  value,
  subtitle,
  trend,
  icon,
}: StatCardProps) {
  return (
    <section className="rounded-2xl border border-line bg-bone p-6 transition-all duration-200 hover:-translate-y-1 hover:shadow-lg">
      <div className="flex items-start justify-between">
        <div>
          <p className="label-mono text-ash mb-2">
            {title}
          </p>

          <h3 className="font-serif text-[30px] leading-none text-obsidian">
            {value}
          </h3>

          {subtitle && (
            <p className="mt-3 text-sm text-ash">
              {subtitle}
            </p>
          )}
        </div>

        {icon && (
          <div className="rounded-xl border border-line bg-bone-deep p-3">
            {icon}
          </div>
        )}
      </div>

      {trend !== undefined && (
        <div
          className={`mt-5 text-sm font-mono ${
            trend >= 0
              ? "text-emerald-700"
              : "text-red-600"
          }`}
        >
          {trend >= 0 ? "+" : ""}
          {trend}% this month
        </div>
      )}
    </section>
  );
}