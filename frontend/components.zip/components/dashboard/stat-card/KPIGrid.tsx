"use client";

import type { AdvisorDashboard } from "@/lib/api";
import {
  Users,
  CalendarClock,
  UserPlus,
  UsersRound,
} from "lucide-react";

import StatCard from "./StatCard";

interface KPIGridProps {
  advisor: AdvisorDashboard;
}

export default function KPIGrid({
  advisor,
}: KPIGridProps) {
  return (
    <section className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard
        title="Total Clients"
        value={advisor.total_clients ?? 0}
        icon={<UsersRound size={22} />}
      />

      <StatCard
        title="Active Clients"
        value={advisor.active_clients ?? 0}
        subtitle={
          advisor.total_clients != null
            ? `${advisor.total_clients} clients assigned`
            : undefined
        }
        icon={<Users size={22} />}
      />

      <StatCard
        title="New Clients"
        value={advisor.new_clients_this_month ?? 0}
        subtitle="This month"
        icon={<UserPlus size={22} />}
      />

      <StatCard
        title="Upcoming Reviews"
        value={advisor.upcoming_reviews ?? 0}
        subtitle="Scheduled"
        icon={<CalendarClock size={22} />}
      />
    </section>
  );
}