import type { AdvisorDashboard } from "@/lib/api";

import WelcomePanel from "./WelcomePanel";
import AdvisorSnapshot from "./AdvisorSnapshot";

interface Props {
  advisor: AdvisorDashboard;
}

export default function DashboardOverview({
  advisor,
}: Props) {
  return (
    <section className="grid gap-6 xl:grid-cols-[2fr_1fr]">

      <WelcomePanel
        advisor={advisor}
      />

      <AdvisorSnapshot
        advisor={advisor}
      />

    </section>
  );
}