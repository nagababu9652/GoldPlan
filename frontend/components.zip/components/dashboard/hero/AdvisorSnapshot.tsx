"use client";

import type { AdvisorDashboard } from "@/lib/api";

interface AdvisorSnapshotProps {
  advisor: AdvisorDashboard;
}

export default function AdvisorSnapshot({
  advisor,
}: AdvisorSnapshotProps) {
  const snapshotItems = [
    {
      label: "Assets Under Management",
      value: `₹${(
        advisor.total_aum ??
        advisor.portfolio_value ??
        0
      ).toLocaleString("en-IN")}`,
    },
    {
      label: "Active Clients",
      value: advisor.active_clients ?? 0,
    },
    {
      label: "Upcoming Reviews",
      value: advisor.upcoming_reviews ?? 0,
    },
    {
      label: "Client Satisfaction",
      value: `${advisor.client_satisfaction ?? "0.0"}/5.0`,
    },
    {
      label: "Reviews Completed",
      value: advisor.reviews_completed ?? 0,
    },
    {
      label: "New Clients",
      value: advisor.new_clients_this_month ?? 0,
    },
  ];

  return (
    <section className="rounded-2xl border border-line bg-bone p-6">
      <div className="mb-6">
        <div className="label-mono text-ash">
          Today's Snapshot
        </div>
      </div>

      <div className="space-y-5">
        {snapshotItems.map((item) => (
          <div
            key={item.label}
            className="flex items-center justify-between border-b border-line pb-4 last:border-b-0 last:pb-0"
          >
            <span className="text-sm text-ash">
              {item.label}
            </span>

            <span className="font-serif text-lg text-obsidian">
              {item.value}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-xl border border-line bg-bone-deep p-4">
        <div className="label-mono mb-2 text-ash">
          Portfolio Growth
        </div>

        <div
          className={`text-2xl font-serif ${
            (advisor.portfolio_change ?? 0) >= 0
              ? "text-emerald-700"
              : "text-red-600"
          }`}
        >
          {(advisor.portfolio_change ?? 0) >= 0 ? "+" : ""}
          {advisor.portfolio_change ?? 0}%
        </div>

        <p className="mt-1 text-xs text-ash">
          Compared with last month
        </p>
      </div>
    </section>
  );
}