"use client";

import type { AdvisorDashboard } from "@/lib/api";

interface Props {
  advisor?: AdvisorDashboard | null;
}

export default function WelcomePanel({
  advisor: advisorData,
}: Props) {

  const hour = new Date().getHours();

  const greeting =
    hour < 12
      ? "Good Morning"
      : hour < 17
      ? "Good Afternoon"
      : "Good Evening";

  const advisor = {
    firstName: advisorData?.advisor_name?.split(" ")[0] || "Chinni",
    role: "Senior Financial Advisor",
    branch: "Hyderabad",
  };

  return (
    <section className="rounded-2xl border border-line bg-bone p-8">

      <div className="label-mono text-ash mb-3">
        Advisor Workspace
      </div>

      <h1 className="display text-[42px] leading-tight">

        {greeting},{" "}

        <em>{advisor.firstName}</em>

        👋

      </h1>

      <p className="mt-5 max-w-2xl text-[16px] leading-[1.7] text-ash">

        Welcome back to FinPlan.

        Manage clients, portfolios, investments, meetings,
        reports and documents from one workspace.

      </p>

      <div className="mt-8 flex flex-wrap gap-3">

        <span className="border border-line px-4 py-2 text-[13px] font-mono">

          {advisor.role}

        </span>

        <span className="border border-line px-4 py-2 text-[13px] font-mono">

          📍 {advisor.branch}

        </span>

      </div>

    </section>
  );
}